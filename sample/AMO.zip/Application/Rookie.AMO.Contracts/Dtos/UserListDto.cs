﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rookie.AMO.Contracts.Dtos
{
    public class UserListDto
    {
        public string UserName { get; set; }
        public string UserID { get; set; }
    }
}
