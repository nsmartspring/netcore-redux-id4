Step 1: Right click to Solution -> Set Multiple startup projects.
Step 2: Run Ctrl + F5.
Step 3: Login using account: Username = "User1", Password = "u123".

References:
https://ivanthag.wixsite.com/reactdotnet/post/adding-oauth-to-a-net-core-react-redux-app-with-identity-server-4-and-redux-oidc-part-1
https://dev.to/tappyy/oidc-authentication-with-react-identity-server-4-3h0d
https://github.com/identityserver/identityserver4.Quickstart.UI