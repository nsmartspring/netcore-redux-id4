﻿namespace Rookie.AMO.Tests.Validations
{
    public class FluentValidationFixture
    {
        static FluentValidationFixture() => ValidationUtils.SetupValidatorOptions();
    }
}
