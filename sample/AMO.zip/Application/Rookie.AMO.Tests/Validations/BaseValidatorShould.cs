﻿using Xunit;

namespace Rookie.AMO.Tests.Validations
{
    public abstract class BaseValidatorShould : IClassFixture<FluentValidationFixture>
    {
    }
}
